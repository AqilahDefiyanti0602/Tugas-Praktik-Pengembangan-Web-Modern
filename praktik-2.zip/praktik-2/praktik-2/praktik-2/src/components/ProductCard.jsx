import React, { Fragment } from "react";

const ProductCard = ({ name, price, isAvailable }) => {
  const formattedPrice = new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(price);

  return (
    <Fragment>
      <div
        style={{
          border: "2px solid #e0e0e0",
          borderRadius: "12px",
          padding: "18px",
          width: "260px",
          background: "#fafafa",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          justifyContent: "space-between",
          gap: "10px",
          transition: "transform 0.2s ease",
        }}
        onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.03)")}
        onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
      >
        <div style={{ width: "100%" }}>
          <h3 style={{ margin: "0", color: "#333", fontSize: "18px" }}>
            {name}
          </h3>
        </div>

        {isAvailable ? (
          <div
            style={{
              color: "#0a8754",
              fontWeight: "600",
              fontSize: "16px",
            }}
          >
            {formattedPrice}
          </div>
        ) : (
          <div
            style={{
              color: "#999",
              fontStyle: "italic",
              background: "#f0f0f0",
              padding: "4px 8px",
              borderRadius: "6px",
              fontSize: "14px",
            }}
          >
            Stok Habis
          </div>
        )}
      </div>
    </Fragment>
  );
};

export default ProductCard;
