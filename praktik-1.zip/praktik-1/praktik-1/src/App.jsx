import "./App.css";

function App() {
  return (
    <>
      <h1>Hello React</h1>
      <div className="card"></div>
    </>
  );
}

export default App;
