export default function Home() {
  return (
    <div className="center">
      <h1>Halo, ini adalah Praktik 4 Next.js</h1>
      <p>Halaman utama menggunakan file page.jsx</p>
    </div>
  );
}
