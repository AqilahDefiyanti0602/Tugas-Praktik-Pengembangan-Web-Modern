import React, { useState } from "react";
import "./App.css";
import Counter from "./Counter";
import UserForm from "./UserForm";
import TodoList from "./TodoList.jsx"; // Sudah ter-import

function App() {
  // Tetap menggunakan 'counter' sebagai default
  const [currentView, setCurrentView] = useState("counter");

  return (
    <div className="App">
      <header className="App-header">
        <h1>State Management dengan useState</h1>
        <nav className="nav-tabs">
          {/* Tombol Counter */}
          <button
            onClick={() => setCurrentView("counter")}
            className={currentView === "counter" ? "active" : ""}
          >
            Counter App
          </button>

          {/* Tombol User Form */}
          <button
            onClick={() => setCurrentView("form")}
            className={currentView === "form" ? "active" : ""}
          >
            User Form
          </button>

          {/*Tombol Todo List */}
          <button
            onClick={() => setCurrentView("todo")} // Mengubah state ke 'todo'
            className={currentView === "todo" ? "active" : ""}
          >
            Todo List
          </button>
        </nav>
      </header>
      <main className="App-main">
        {currentView === "counter" && <Counter />}
        {currentView === "form" && <UserForm />}

        {/* 👈 BARU: Rendering kondisional untuk TodoList */}
        {currentView === "todo" && <TodoList />}
      </main>
      <footer className="App-footer">
        <p>Pertemuan 4 - State Management Dasar</p>
      </footer>
    </div>
  );
}

export default App;
