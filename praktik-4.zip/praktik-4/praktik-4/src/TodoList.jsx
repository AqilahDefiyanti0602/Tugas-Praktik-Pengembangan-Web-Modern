import React, { useState } from "react";

const TodoList = () => {
  const [todos, setTodos] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [filter, setFilter] = useState("all");

  const addTodo = () => {
    if (inputValue.trim() === "") return;
    const newTodo = {
      id: Date.now(),
      text: inputValue.trim(),
      completed: false,
    };
    setTodos((prev) => [...prev, newTodo]);
    setInputValue("");
  };

  const deleteTodo = (id) => {
    setTodos((prev) => prev.filter((t) => t.id !== id));
  };

  const toggleComplete = (id) => {
    setTodos((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const filteredTodos = todos.filter((t) => {
    if (filter === "active") return !t.completed;
    if (filter === "completed") return t.completed;
    return true;
  });

  const totalTodos = todos.length;
  const activeTodos = todos.filter((t) => !t.completed).length;

  const renderTodos = () => {
    if (filteredTodos.length === 0) {
      return (
        <p style={{ textAlign: "center", color: "#aaa", fontStyle: "italic" }}>
          Belum ada todo di kategori ini 💭
        </p>
      );
    }
    return (
      <ul style={listStyle}>
        {filteredTodos.map((todo) => (
          <li key={todo.id} style={todoItemStyle}>
            <div
              onClick={() => toggleComplete(todo.id)}
              style={{
                ...todoTextStyle,
                textDecoration: todo.completed ? "line-through" : "none",
                color: todo.completed ? "#999" : "#333",
              }}
            >
              <input
                type="checkbox"
                checked={todo.completed}
                onChange={() => toggleComplete(todo.id)}
                style={{ marginRight: "10px" }}
              />
              {todo.text}
            </div>
            <button
              onClick={() => deleteTodo(todo.id)}
              style={deleteButtonStyle}
            >
              ✖
            </button>
          </li>
        ))}
      </ul>
    );
  };

  // 🌸 Styles baru — pastel vibes
  const containerStyle = {
    maxWidth: "600px",
    margin: "40px auto",
    backgroundColor: "#fff8f5",
    borderRadius: "16px",
    boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
    padding: "25px",
    fontFamily: "Poppins, sans-serif",
  };

  const headerStyle = {
    textAlign: "center",
    color: "#ff6f61",
    marginBottom: "20px",
  };

  const inputGroupStyle = {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "20px",
  };

  const inputStyle = {
    flexGrow: 1,
    border: "2px solid #ffb6b9",
    padding: "10px 15px",
    borderRadius: "8px",
    outline: "none",
    fontSize: "1rem",
  };

  const buttonStyle = {
    marginLeft: "10px",
    padding: "10px 18px",
    backgroundColor: "#ff6f61",
    color: "white",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    transition: "0.3s",
  };

  const filterGroupStyle = {
    display: "flex",
    justifyContent: "center",
    gap: "10px",
    marginBottom: "15px",
  };

  const filterButtonStyle = (currentFilter) => ({
    padding: "8px 14px",
    borderRadius: "20px",
    border: "none",
    backgroundColor:
      filter === currentFilter ? "#ff6f61" : "rgba(255,111,97,0.2)",
    color: filter === currentFilter ? "white" : "#ff6f61",
    fontWeight: "500",
    cursor: "pointer",
    transition: "0.3s",
  });

  const listStyle = {
    listStyle: "none",
    padding: 0,
  };

  const todoItemStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#fff",
    borderRadius: "10px",
    marginBottom: "10px",
    padding: "10px 15px",
    boxShadow: "0 2px 5px rgba(0,0,0,0.05)",
  };

  const todoTextStyle = {
    display: "flex",
    alignItems: "center",
    flexGrow: 1,
    cursor: "pointer",
  };

  const deleteButtonStyle = {
    backgroundColor: "#ffb6b9",
    border: "none",
    borderRadius: "50%",
    width: "28px",
    height: "28px",
    color: "#fff",
    fontWeight: "bold",
    cursor: "pointer",
    transition: "0.3s",
  };

  const statsStyle = {
    textAlign: "center",
    marginTop: "20px",
    color: "#666",
  };

  return (
    <div style={containerStyle}>
      <h2 style={headerStyle}>🌸 Daftar To do List 🌸</h2>

      <div style={inputGroupStyle}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addTodo()}
          placeholder="Tulis to do baru..."
          style={inputStyle}
        />
        <button onClick={addTodo} style={buttonStyle}>
          Tambah
        </button>
      </div>

      <div style={filterGroupStyle}>
        <button
          onClick={() => setFilter("all")}
          style={filterButtonStyle("all")}
        >
          Semua ({totalTodos})
        </button>
        <button
          onClick={() => setFilter("active")}
          style={filterButtonStyle("active")}
        >
          Aktif ({activeTodos})
        </button>
        <button
          onClick={() => setFilter("completed")}
          style={filterButtonStyle("completed")}
        >
          Selesai ({totalTodos - activeTodos})
        </button>
      </div>

      {renderTodos()}

      <div style={statsStyle}>
        <p>
          Total: <b>{totalTodos}</b> | Aktif: <b>{activeTodos}</b>
        </p>
      </div>
    </div>
  );
};

export default TodoList;
