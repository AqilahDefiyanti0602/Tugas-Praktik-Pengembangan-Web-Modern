import React from 'react';
import { ThemeContext } from './contexts/ThemeContext';

function App() {
  const [theme, setTheme] = useState('light');
  return (
    <>
      <ThemeContext.Provider value={{ theme, setTheme}}>
        
        
      </ThemeContext.Provider>
    </>
  )
}

export default App;