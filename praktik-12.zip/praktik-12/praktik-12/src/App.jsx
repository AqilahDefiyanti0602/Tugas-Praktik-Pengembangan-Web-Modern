// App.jsx
import React from "react";
import Counter from "./features/Counter.jsx";

const App = () => {
    return (
        <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
            <h1>Redux Toolkit Counter Example</h1>
            <Counter />
        </div>
    );
};

export default App;