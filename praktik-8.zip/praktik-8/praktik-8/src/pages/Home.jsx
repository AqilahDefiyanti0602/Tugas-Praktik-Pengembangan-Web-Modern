import React from 'react';

function Home() {
    return (
        <>
            <h1>Home Page</h1>
            <p>Welcome to the Home page!</p>
        </>
    )
}


export default Home;