import React from 'react';

export default function Profile() {
    return (
        <>
            <h1>Profile Page</h1>
            <p>This is the Profile Page.</p>
        </>
    )
}