import React from 'react';

const Contact = () => {
    return (
        <>
            <h1>Contact Page</h1>
            <p>This is the Contact Page.</p>
        </>
    )
}

export default Contact;