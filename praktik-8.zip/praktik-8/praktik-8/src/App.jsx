import React from 'react';
import RouterA from './routes/RouterA';

function App() {
  return (
    <div className="App">
      <RouterA />
    </div>
  )
}

export default App;