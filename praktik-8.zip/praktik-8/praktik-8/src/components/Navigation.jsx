import React from 'react';
import { Link } from 'react';

const Navigation = () => {
    return (
        <nav>
            <Link to='/'>Home</Link>
            <Link to='/profile'>Profile</Link>
            <Link to='/contact'>Contact</Link>
            <a href='/contact'>Contact(a tag)</a>
        </nav>
    )
}

export default Navigation