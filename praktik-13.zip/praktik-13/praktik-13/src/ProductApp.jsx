import React, { useState, useEffect } from "react";
import "./App.css";

const API_URL = "http://localhost/praktik-13/api.php";

function ProductApp() {
  const [products, setProducts] = useState([]);
  const [nama, setNama] = useState("");
  const [harga, setHarga] = useState("");
  const [editId, setEditId] = useState(null);

  // Fetch data produk
  const fetchProducts = async () => {
    const res = await fetch(API_URL);
    const data = await res.json();
    setProducts(data);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Tambah Produk
  const handleAdd = async () => {
    if (!nama || !harga) return alert("Isi semua field!");

    await fetch(API_URL, {
      method: "POST",
      body: JSON.stringify({ nama, harga }),
    });

    setNama("");
    setHarga("");
    fetchProducts();
  };

  // Hapus produk
  const handleDelete = async (id) => {
    await fetch(`${API_URL}?id=${id}`, { method: "DELETE" });
    fetchProducts();
  };

  // Edit produk
  const handleEdit = (product) => {
    setEditId(product.id);
    setNama(product.nama);
    setHarga(product.harga);
  };

  // Simpan perubahan edit
  const handleSave = async () => {
    await fetch(API_URL, {
      method: "PUT",
      body: JSON.stringify({
        id: editId,
        nama,
        harga,
      }),
    });

    setEditId(null);
    setNama("");
    setHarga("");
    fetchProducts();
  };

  return (
    <div className="container">
      <h1>Manajemen Produk 🛒</h1>

      {/* Form Tambah Produk */}
      <div className="form">
        <input
          type="text"
          placeholder="Nama Produk"
          value={nama}
          onChange={(e) => setNama(e.target.value)}
        />
        <input
          type="number"
          placeholder="Harga"
          value={harga}
          onChange={(e) => setHarga(e.target.value)}
        />

        {editId ? (
          <button className="edit" onClick={handleSave}>
            Simpan
          </button>
        ) : (
          <button className="add" onClick={handleAdd}>
            Tambah Produk
          </button>
        )}
      </div>

      <h2>Daftar Produk (Kristin Impana Manik)</h2>

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Harga</th>
            <th>Aksi</th>
          </tr>
        </thead>

        <tbody>
          {products.length === 0 ? (
            <tr>
              <td colSpan="4" style={{ textAlign: "center" }}>
                Tidak ada produk.
              </td>
            </tr>
          ) : (
            products.map((p) => (
              <tr key={p.id}>
                <td>{p.id}</td>
                <td>{p.nama}</td>
                <td>{p.harga}</td>
                <td>
                  <button className="edit" onClick={() => handleEdit(p)}>
                    Edit
                  </button>
                  <button className="delete" onClick={() => handleDelete(p.id)}>
                    Hapus
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default ProductApp;
