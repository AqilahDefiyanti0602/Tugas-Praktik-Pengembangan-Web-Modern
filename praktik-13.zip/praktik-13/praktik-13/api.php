<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];
$file = "data.json";

if (!file_exists($file)) {
    file_put_contents($file, json_encode([]));
}

$products = json_decode(file_get_contents($file), true);

switch ($method) {
    case "GET":
        echo json_encode($products);
        break;

    case "POST":
        $json = json_decode(file_get_contents("php://input"), true);
        $json["id"] = time();
        $products[] = $json;
        file_put_contents($file, json_encode($products));
        echo json_encode(["message" => "Produk ditambah"]);
        break;

    case "PUT":
        $json = json_decode(file_get_contents("php://input"), true);
        foreach ($products as &$p) {
            if ($p["id"] == $json["id"]) {
                $p = $json;
            }
        }
        file_put_contents($file, json_encode($products));
        echo json_encode(["message" => "Produk diupdate"]);
        break;

    case "DELETE":
        $id = $_GET["id"] ?? null;
        $products = array_filter($products, fn($p) => $p["id"] != $id);
        file_put_contents($file, json_encode(array_values($products)));
        echo json_encode(["message" => "Produk dihapus"]);
        break;
}
